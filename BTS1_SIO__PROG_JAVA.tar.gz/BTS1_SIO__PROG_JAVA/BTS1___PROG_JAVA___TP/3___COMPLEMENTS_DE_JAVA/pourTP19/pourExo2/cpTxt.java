package tpjdbc.exo1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Iterator;

public class cpTxt {
	public static void main(String args[]) {
		try {
			ArrayList<String> storeWordList = new ArrayList<String>();
			FileInputStream fstream = new FileInputStream(args[0]);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				storeWordList.add(strLine);

			}
			//Close the input stream
			in.close();

			Writer output = null;
			File file = new File(args[0].replaceAll(".txt", "_sauv.txt"));
			output = new BufferedWriter(new FileWriter(file));
			for (Iterator<String> iter = storeWordList.iterator(); iter.hasNext();) {
				String line = (String) iter.next(); 
				String[] words = line.split(" ");
				for(int i=0; i<words.length; i++)
					output.write(words[i]+" ");
			}

			output.close();
			System.out.println("Your file has been written");

		} catch(FileNotFoundException e) {
			System.err.println("Error: " + e.getMessage());
		} catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println("Usage : cptTxt fileName");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}
}