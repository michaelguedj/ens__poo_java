package tp_algo_base_java;

public class Tp7 {

	public static boolean estVide(int t[]) {
		if (t.length==0) return true;
		return false;
	}
	
	public static int maximum(int t[]) {
		int max = t[0];
		for (int i=1; i<t.length; i++)
			if (max < t[i]) max = t[i];
		return  max;
	}
	
	public static int somme(int t[]) {
		int res = 0;
		for (int i=0; i<t.length; i++)
			res += t[i];
		return res;
	}
	
	public static double moyenne(int t[]) {
		if (estVide(t)) return 0;
		return ((double)somme(t))/t.length;
	}
	
	public static boolean tousEgaux(int t[]) {
		for (int i=1; i<t.length; i++)
			if (t[0] != t[i]) return false;
		return true;
	}
	
	public static int produitScalaire(int t1[], int t2[]) {
		int res = 0;
		for (int i=0; i<t1.length; i++)
			res += t1[i]*t2[i];
		return res;
	}
	
	public static boolean egaux(int t1[], int t2[]) {
		for (int i=1; i<t1.length; i++)
			if (t1[i] != t2[i]) return false;
		return true;
	}
	
	public static boolean estTrie(int t[]) {
		for (int i=0; i<t.length-1; i++)
			if (t[i]>t[i+1]) return false;
		return true;
	}
	
	public static void main(String[] args) {
		int t1[] = {2,4,5,5,3};
		int t2[] = {};
		int t3[] = {1,1,1,1,1};
		int t1_bis[] = t1.clone(); 
		
		System.out.println(estVide(t1));
		System.out.println(estVide(t2));
		
		System.out.println(maximum(t1));
		System.out.println(somme(t1));
		System.out.println(moyenne(t1));
		
		System.out.println(tousEgaux(t1));
		System.out.println(tousEgaux(t2));
		System.out.println(tousEgaux(t3));
		
		System.out.println(produitScalaire(t1, t3));
		
		System.out.println(egaux(t1, t3));
		System.out.println(egaux(t1, t1_bis));
		
		int t4[] = {1,2,3,4,4,5};
		
		System.out.println(estTrie(t1));
		System.out.println(estTrie(t2));
		System.out.println(estTrie(t3));
		System.out.println(estTrie(t4));
	}
}
