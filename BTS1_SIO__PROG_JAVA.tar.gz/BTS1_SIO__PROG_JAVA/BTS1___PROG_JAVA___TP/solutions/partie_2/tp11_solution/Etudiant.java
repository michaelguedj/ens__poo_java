package tp11;

public class Etudiant {
	private int age;
	private String nom;
	private String prenom;
	private String etablissement;
	private boolean apprenti;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
