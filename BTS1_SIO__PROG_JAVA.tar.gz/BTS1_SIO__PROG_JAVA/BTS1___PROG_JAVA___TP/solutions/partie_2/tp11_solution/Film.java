package tp11;

public class Film {
	private String titre;
	private int annee;
	private String pays;
	private String langue;
	private String realisateur;
	private String genre;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
