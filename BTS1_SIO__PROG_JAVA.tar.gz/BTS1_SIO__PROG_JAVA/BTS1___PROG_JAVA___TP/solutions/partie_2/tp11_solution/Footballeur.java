package tp11;

public class Footballeur {
	private int age;
	private double taille;
	private double poids;
	private String nom;
	private String prenom;
	private String equipe;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
