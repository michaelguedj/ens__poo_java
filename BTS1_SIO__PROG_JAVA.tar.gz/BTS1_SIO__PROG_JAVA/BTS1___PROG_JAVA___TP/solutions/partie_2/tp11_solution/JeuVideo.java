package tp11;

public class JeuVideo {
	private String titre;
	private int annee;
	private String studio;
	private boolean enFrancais;
	private String console;
	private String genre;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
