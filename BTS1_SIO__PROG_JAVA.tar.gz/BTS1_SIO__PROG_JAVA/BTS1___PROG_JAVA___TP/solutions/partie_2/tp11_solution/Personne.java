package tp11;

public class Personne {
	private String nom;
	private String prenom;
	private int age;
	private boolean francais;
	
	// Constructeurs
	// -- Constructeur A
	public Personne(String unNom, String unPrenom, int unAge, 
			boolean estFrancais) {
		nom = unNom;
		prenom = unPrenom;
		age = unAge;
		francais = estFrancais; 
	}
	
	// -- Constructeur B
	public Personne(String unNom, String unPrenom, int unAge) {
		this(unNom, unPrenom, unAge, false);
	}
	
	// -- Constructeur C
	public Personne(String unNom, String unPrenom) {
		this(unNom, unPrenom, -1, false);
	}
	
	// -- Constructeur D
	public Personne(String unNom) {
		this(unNom, "", -1, false);
	}
	
	// Accesseurs
	public int getAge() {
		return age;
	}
	
	// Modificateurs
	public void setAge(int unAge) {
		age = unAge;
	}
	
	public static void main(String[] args) {
		Personne p = new Personne("Dupond");
	}
}
