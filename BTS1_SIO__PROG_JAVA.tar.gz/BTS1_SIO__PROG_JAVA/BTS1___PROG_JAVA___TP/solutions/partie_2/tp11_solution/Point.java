package tp11;

public class Point {

	// Attributs 
	private double x;
	private double y;
	
	// Constructeurs
	// Premier constructeur
	public Point(double unX, double unY) {
		x = unX;
		y = unY;
	}
	// Deuxi�me constructeur
	public Point(double unX) {
		x = unX;
		y = unX;
	}
	
	// Accesseurs
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	// Modificateurs
	public void setX(double unX) {
		x = unX;
	}
	
	public void setY(double unY) {
		y = unY;
	}
	
	// M�thode d'affichage
	public void afficher() {
		System.out.println("x="+x+"; y="+y);
	}
	
	public static void main(String[] args) {
		Point p = new Point(1.0, 2.3);
		p.afficher();
		System.out.println(p.getX());
		System.out.println(p.getY());
		p.setX(3.2);
		p.afficher();
		Point p2 = new Point(1.0);
		//1-
		p2.afficher();
		//3-
		Point p3 = new Point(1.3, 2.3);
		p3.afficher();
		System.out.println(p3.x);
		p3.setX(10);
		p3.afficher();
		//4-
		Point p4 = new Point(1.3);
		p4.afficher();
		System.out.println(p4.y);
		p4.setY(10);
		p4.afficher();
	}
}
