package tp12;

public class JeuVideo {

	private String titre;
	private int annee;
	private String studio;
	private boolean enFrancais;
	private String console;
	private String genre;


	public String getConsole() {
		return console;
	}

	public void setConsole(String console) {
		this.titre = console; 	
	}
	
	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public int getAnnee() {
		return annee;
	}

	public void setAnnee(int annee) {
		this.annee = annee;
	}

	public String getStudio() {
		return studio;
	}

	public void setStudio(String studio) {
		this.studio = studio;
	}

	public boolean isEnFrancais() {
		return enFrancais;
	}

	public void setEnFrancais(boolean enFrancais) {
		this.enFrancais = enFrancais;
	}

	public String getGenre() {
		return genre;
	}

	public void setGenre(String genre) {
		this.genre = genre;
	}

	public void affichage() {
		System.out.println("Titre : "+ titre);
		System.out.println("Ann�e : "+ annee);
		System.out.println("Studio : "+ studio);
		System.out.println("VF ? : "+ enFrancais);
		System.out.println("Console : "+ console);
		System.out.println("Genre : "+ genre);
	}

	public boolean estEgal(JeuVideo jeu) {
		if (getTitre() != jeu.getTitre()) return false;
		if (getAnnee() != jeu.getAnnee()) return false;
		if (getStudio() != jeu.getStudio()) return false;
		if (isEnFrancais() != jeu.isEnFrancais()) return false;
		if (getGenre() != jeu.getGenre()) return false;
		if (getConsole() != jeu.getConsole()) return false;
		return true;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
