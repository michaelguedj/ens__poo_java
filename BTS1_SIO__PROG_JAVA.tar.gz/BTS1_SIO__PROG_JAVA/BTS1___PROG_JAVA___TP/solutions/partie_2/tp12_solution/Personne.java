package tp12;

public class Personne {
	private String nom;
	private String prenom;
	private int age;
	private boolean francais;
	
	// Constructeurs
	// -- Constructeur A
	public Personne(String unNom, String unPrenom, int unAge, 
			boolean estFrancais) {
		nom = unNom;
		prenom = unPrenom;
		age = unAge;
		francais = estFrancais; 
	}
	
	// -- Constructeur B
	public Personne(String unNom, String unPrenom, int unAge) {
		this(unNom, unPrenom, unAge, false);
	}
	
	// -- Constructeur C
	public Personne(String unNom, String unPrenom) {
		this(unNom, unPrenom, -1, false);
	}
	
	// -- Constructeur D
	public Personne(String unNom) {
		this(unNom, "", -1, false);
	}
	
	// Accesseurs (getter)
	// -- A G�n�rer
	
	// Modificateurs (setter)
	// -- A G�n�rer
	
	// M�thode d'affichage
	public void affichage() {
		// Affiche les propri�t�s de 
		// l'objet courant
		// -- Code � donner --
		;
	}
	
	// Test d'�galit�
	public boolean estEgal(Personne P) {
		// -- Code � donner --
		return true;
	}
	
	public boolean homonyme(Personne P) {
		// retourne vrai si les noms de this
		// et de P sont identiques
		// -- Code � donner --
		return true;
	}
	
	public static void main(String[] args) {
		Personne p = new Personne("Dupond");
	}
}
