package tp12;

public class Point {

	// Propri�t�s 
	private double x;
	private double y;
	
	// Constructeurs
	// Premier constructeur
	public Point(double unX, double unY) {
		x = unX;
		y = unY;
	}
	// Deuxi�me constructeur
	public Point(double unX) {
		x = unX;
		y = unX;
	}
	
	// Accesseurs
	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}
	
	// Modificateurs
	public void setX(double unX) {
		x = unX;
	}
	
	public void setY(double unY) {
		y = unY;
	}
	
	// M�thode d'affichage
	public void afficher() {
		System.out.println("x="+x+"; y="+y);
	}
	
	// Autres m�thodes 
	public void addition(Point p) {
		// this = this + p
		x = x + p.x;
		y = y + p.y;
	}
	
	public void addition(Point p1, Point p2) {
		// this = this + p1 + p2
	}
	
	public boolean estNul() {
		// Test si l'objet courant est le point nul 
		// c-a-d est �gal � (0, 0)
		// -- Code � donner --
		return false;
	}
	
	public boolean estEgal(Point p) {
		// Test si l'objet courant est �gal � p ; 
		// c-a-d x=p.x et y=p.y
		// -- Code � donner --
		return false;
	}
	
	
	public static void main(String[] args) {
		Point p = new Point(1.0, 2.3);
		Point p2 = new Point(1, 1);
		p.addition(p2);
		p.afficher();
		p2.afficher();
	}
}