package tp12;

public class Test {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "toto";
		System.out.println(s);
		s="tata";
		System.out.println(s);
	}

}
