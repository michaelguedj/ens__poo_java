package tp13;

public class Livre {

	// Variables
	private String titre, auteur;
	private int nbPages;

	// Constructeurs
	public Livre() {}
	
	public Livre(String unAuteur, String unTitre) {
		setAuteur(unAuteur);
		setTitre(unTitre);
	}

	public Livre(String unAuteur, String unTitre, int nbPages) {
		setAuteur(unAuteur);
		setTitre(unTitre);
		setNbPages(nbPages);
	}
	
	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public int getNbPages() {
		return nbPages;
	}

	public void setNbPages(int nbPages) {
		if (nbPages >= 0) {
			this.nbPages = nbPages;
		}
		else {
			System.out.println("Le nombre de page doit etre positif !");
		}
	}
	
	public void afficheToi() {
		System.out.println("Titre : " + titre);
		System.out.println("Auteur : " + auteur);
		System.out.println("Nombre de Page : " + nbPages);
		System.out.println("---------------------");
	}
	
	public String toString() {
		String res = "Titre : " + titre + "\n";
		res += "Auteur : " + auteur + "\n";
		res += "Nombre de Page : " + nbPages + "\n";
		res += "---------------------\n";
		return res;
	}
	
	public boolean estEgal(Livre lv) {
		return titre.equals(lv.getTitre()) &&
				auteur.equals(lv.getAuteur()) &&
				nbPages == lv.getNbPages();
	}
}

