package tp13;

public class TestLivre {

	public static void main(String[] args) {
		Livre l1, l2;
		l1 = new Livre("Toto", "Titre 1");
		System.out.println(l1);
		l2 = new Livre("Tata", "Titre 2");
		System.out.println(l1.getAuteur());
		System.out.println(l2.getAuteur());
		
		// Exo 2
		l1.setNbPages(200);
		l2.setNbPages(-1);
		System.out.println(l1.getNbPages());
		System.out.println(l2.getNbPages());
		l2.setNbPages(45);
		System.out.println(l2.getNbPages());
		int nbPageTotal =  l1.getNbPages()+l2.getNbPages();
		System.out.println("nb pages total : " + nbPageTotal);
		
		// Exo 4
		l1.afficheToi();
		l2.afficheToi();
		
		System.out.println(l1);
		System.out.println(l2);
		
		// Exo 5
		Livre l3;
		l3 = new Livre();
		l3.setAuteur("Victor Hugo");
		System.out.println(l3);

		// Utilisation des 3 constructeurs
		Livre l4, l5, l6;
		l4 = new Livre("Toto", "Titre 1", 300);
		System.out.println(l4);
		//
		l5 = new Livre("Toto", "Titre 2");
		l5.setNbPages(300);
		System.out.println(l5);
		//
		l6 = new Livre();
		l6.setAuteur("Toto");
		l6.setTitre("Titre 3");
		l6.setNbPages(300);
		System.out.println(l6);
		
		// Exo 6
		Livre lv1, lv2;
		lv1 = new Livre("Toto", "Titre", 300);
		lv2 = new Livre("Toto", "Titre", 300);
		System.out.println(lv1 == lv2);
		System.out.println(lv1.estEgal(lv2));
	}
}
