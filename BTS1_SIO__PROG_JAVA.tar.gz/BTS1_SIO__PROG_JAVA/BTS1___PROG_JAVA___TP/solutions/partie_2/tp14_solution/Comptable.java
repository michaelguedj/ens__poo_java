package tp14;

public class Comptable {
	private double prixTotal=0;
	
	public void comptabiliser(Livre lv) {
		prixTotal += lv.getPrix();
	}

	public double getPrixTotal() {
		return prixTotal;
	}

	public void setPrixTotal(double prixTotal) {
		this.prixTotal = prixTotal;
	}

}
