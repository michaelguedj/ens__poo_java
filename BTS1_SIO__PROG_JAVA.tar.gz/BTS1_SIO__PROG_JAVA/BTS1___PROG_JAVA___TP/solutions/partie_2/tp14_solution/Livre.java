package tp14;

public class Livre {

	// Variables
	private String titre, auteur;
	private int nbPages;
	private double prix=-1;
	static private Comptable c;

	// Constructeurs
	public Livre() {
		if (Livre.c == null) {
			Livre.c = new Comptable();
		}
	}

	public Livre(String unAuteur, String unTitre) {
		this();
		setAuteur(unAuteur);
		setTitre(unTitre);
	}

	public Livre(String unAuteur, String unTitre, int nbPages) {
		this(unAuteur, unTitre);
		setNbPages(nbPages);

	}

	public Livre(String unAuteur, String unTitre, int nbPages, double prix) {
		this(unAuteur, unTitre, nbPages);
		setPrix(prix);
	}

	public double getPrix() {
		return prix;
	}

	public void setPrix(double prix) {
		if (this.prix == -1) {
			if (prix >= 0) {
				this.prix = prix;
				c.comptabiliser(this);
			}
			else System.out.println("Prix incorrect.\n");
		} else {
			System.err.println("Erreur : prix d�j� donn�.\n");
		}
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public String getAuteur() {
		return auteur;
	}

	public void setAuteur(String auteur) {
		this.auteur = auteur;
	}

	public int getNbPages() {
		return nbPages;
	}

	public void setNbPages(int nbPages) {
		if (nbPages >= 0) {
			this.nbPages = nbPages;
		}
		else {
			System.out.println("Le nombre de page doit etre positif !");
		}
	}

	public String toString() {
		String res = "Titre : " + titre + "\n";
		res += "Auteur : " + auteur + "\n";
		res += "Nombre de Page : " + nbPages + "\n";
		if (prix == -1) {
			res += "Prix : non encore donn�\n";
		} else {
			res += "Prix : " + prix + "\n";			
		}
		res += "---------------------\n";
		return res;
	}

	public boolean estEgal(Livre lv) {
		return titre.equals(lv.getTitre()) &&
				auteur.equals(lv.getAuteur()) &&
				nbPages == lv.getNbPages();
	}

	public boolean isPrixFixe() {
		if (this.prix == -1) return false;
		return true;
	}
	
	public int compare(Livre lv) {
		if (this.nbPages == lv.getNbPages())
			return 0;
		if (this.nbPages > lv.getNbPages())
			return 1;
		return -1;
	}
	
	public static int compare2(Livre lv1, Livre lv2) {
		if (lv1.getNbPages() == lv2.getNbPages())
			return 0;
		if (lv1.getNbPages() > lv2.getNbPages())
			return 1;
		return -1;
	}
	
	public static double getPrixTotal() {
		return Livre.c.getPrixTotal();
	}
}
