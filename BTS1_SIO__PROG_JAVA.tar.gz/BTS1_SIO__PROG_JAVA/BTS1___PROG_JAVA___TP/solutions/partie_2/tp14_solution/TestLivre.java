package tp14;

public class TestLivre {

	public static void main(String[] args) {
		Livre lv1, lv2;
		
		// Exo 1
		lv1 = new Livre("Toto", "Titre 1", 300, 10.5);
		lv2 = new Livre("Tata", "Titre 2", 100);

		System.out.println(lv1);
		System.out.println("Prix fix� ? " + lv1.isPrixFixe() + "\n");
		lv1.setPrix(10);

		System.out.println(lv2);
		System.out.println("Prix fix� ? " + lv2.isPrixFixe() + "\n");
		lv2.setPrix(10);
		System.out.println(lv2);
		
		// Exo 2
		System.out.println("Comparaison : " + lv1.compare(lv2) + "\n");
		System.out.println("Comparaison : " + lv2.compare(lv1) + "\n");
		
		// Exo 3
		System.out.println("Comparaison : " + Livre.compare2(lv1, lv2));
		System.out.println("Comparaison : " + Livre.compare2(lv2, lv1));
		
		// Exo 4 - 1
		Comptable c1 = new Comptable();
		c1.comptabiliser(lv1);
		c1.comptabiliser(lv2);
		System.out.println(c1.getPrixTotal());
		// Exo 4 - 2
		System.out.println(Livre.getPrixTotal());
	}
}
