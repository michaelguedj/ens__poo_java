package tp15;

import java.util.ArrayList;

public class Cadre extends Employe {

	private static int nbCadres = 0;
	private ArrayList<String> listeDesProjets;

	public Cadre(String nom, int salaire) {
		super(nom, salaire);
		nbCadres++;
		listeDesProjets = new ArrayList<String>();
	}

	// getters et setters
	public static int getNbCadres() {
		return nbCadres;
	}

	public static void setNbCadres(int nbCadres) {
		Cadre.nbCadres = nbCadres;
	}

	public ArrayList<String> getListeDesProjets() {
		return listeDesProjets;
	}

	public void setListeDesProjets(ArrayList<String> listeDesProjets) {
		this.listeDesProjets = listeDesProjets;
	}

	// Ajoute un projet � la liste des projets
	public void ajouterUnProjet(String nomProjet) {
		listeDesProjets.add(nomProjet);
	}

	// Affiche � l'�cran l'ensemeble des projets
	public void afficherLesProjets() {
		for(String projet : listeDesProjets) {
			System.out.println(projet);
		}
	}
	
	public String toString() {
		String res = "--- Cadre :\n";
		res += super.toString();
		res += "Projets : ";
		for(String projet : listeDesProjets) {
			res += projet + ", ";
		}
		res += "\n";
		return res;
	}
}