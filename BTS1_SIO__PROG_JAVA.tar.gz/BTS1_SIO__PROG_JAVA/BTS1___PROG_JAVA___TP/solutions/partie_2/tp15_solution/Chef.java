package tp15;

import java.util.ArrayList;

public class Chef extends Cadre {
	private ArrayList<Employe> listeEmployes;
	
	public Chef(String nom, int salaire) {
		super(nom, salaire);
		listeEmployes = new ArrayList<Employe>();
	}
	
	public void ajouterUnEmploye(Employe e) {
		listeEmployes.add(e);
	}
	
	public void afficherLesEmployes() {
		for(Employe e : listeEmployes) {
			System.out.println(e);
		}
	}

	// getter et setter
	public ArrayList<Employe> getListeEmployes() {
		return listeEmployes;
	}

	public void setListeEmployes(ArrayList<Employe> listeEmployes) {
		this.listeEmployes = listeEmployes;
	}
}
