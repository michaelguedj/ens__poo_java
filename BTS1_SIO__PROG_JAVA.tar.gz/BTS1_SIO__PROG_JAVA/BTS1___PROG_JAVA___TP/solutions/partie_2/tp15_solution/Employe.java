package tp15;

public class Employe {
	private static int nbEmployes = 0;
	private String nom;
	private int salaire;
	
	public Employe(String nom, int salaire) {
		setNom(nom);
		setSalaire(salaire);
		nbEmployes++;
	}
	
	public int getSalaire() {
		return salaire;
	}

	public void setSalaire(int salaire) {
		this.salaire = salaire;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public static int getNbEmployes() {
		return nbEmployes;
	}

	public static void setNbEmployes(int nbEmployes) {
		Employe.nbEmployes = nbEmployes;
	}
	
	public String toString() {
		String res = "";
		res += "Nom : " + getNom() + "\n";
		res += "Salaire : " + getSalaire() + "\n";
		return res;
	}
	
}
