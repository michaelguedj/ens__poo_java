package tp15;

import java.util.Scanner;

public class Entreprise {
	public static void main(String[] args) {
		// Travail sur la classe Employe
		System.out.println("-- Travail sur la classe Employe");
		Employe e1 = new Employe("toto", 1000);
		System.out.println(e1);
		System.out.println(e1.getSalaire());

		Scanner clavier = new Scanner(System.in);

		System.out.print("Entrez un nom : "); 
		String nom = clavier.nextLine();
		System.out.print("Entrez un salaire : "); 
		int salaire = clavier.nextInt();
		Employe e2 = new Employe(nom, salaire);
		System.out.println(e2);
		System.out.println(e2.getSalaire());

		System.out.println("le nombre d'employ�s cr�es est : " +
				Employe.getNbEmployes());
		clavier.close();

		// Travail sur la classe Ouvrier
		System.out.println("\n\n-- Travail sur la classe Ouvrier");
		Ouvrier o1 = new Ouvrier("bobo", 1001, 2);
		System.out.println(o1.getNom());
		System.out.println(o1.getSalaire());
		System.out.println(o1.getNumeroAtelier());

		System.out.println("le nombre d'ouvriers cr�es est : " +
				Ouvrier.getNbOuvriers());

		System.out.println("le nombre d'employ�s cr�es est : " +
				Employe.getNbEmployes());

		// Travail sur la classe Technicien
		System.out.println("\n\n-- Travail sur la classe Technicien");
		Technicien t1 = new Technicien("tintin", 1200, "BD");
		System.out.println(t1.getNom());
		System.out.println(t1.getSalaire());
		System.out.println(t1.getService());

		System.out.println("le nombre d'employ�s cr�es est : " +
				Employe.getNbEmployes());

		System.out.println("le nombre de technicien cr�es est : " +
				Technicien.getNbTechniciens());
		
		// Travail sur la classe Cadre
		System.out.println("\n\n-- Travail sur la classe Cadre");
		Cadre c1 = new Cadre("coco", 1700);
		c1.ajouterUnProjet("projet1");
		c1.ajouterUnProjet("projet2");
		c1.afficherLesProjets();
		
		System.out.println("le nombre d'employ�s cr�es est : " +
				Employe.getNbEmployes());
		
		System.out.println("le nombre de cadres cr�es est : " +
				Cadre.getNbCadres());
		
		// Travail sur la classe Chef
		System.out.println("\n\n-- Travail sur la classe Chef");
		Chef chef = new Chef("Yoyo", 3000);
		chef.ajouterUnEmploye(o1);
		chef.ajouterUnEmploye(t1);
		chef.ajouterUnEmploye(c1);
		
		System.out.println("\nLes employ�s de " + chef.getNom() + " sont :");
		chef.afficherLesEmployes();		
	}
}