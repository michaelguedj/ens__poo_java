package tp15;

public class Ouvrier extends Employe{
	private static int nbOuvriers = 0;
	private int numeroAtelier;

	public Ouvrier(String nom, int salaire, int numeroAtelier) {
		super(nom, salaire);	// appel au constructeur parent
								// cad Employe(nom salaire)
		setNumeroAtelier(numeroAtelier);
		nbOuvriers++;
	}
	
	public int getNumeroAtelier() {
		return numeroAtelier;
	}

	public void setNumeroAtelier(int numeroAtelier) {
		this.numeroAtelier = numeroAtelier;
	}

	public static int getNbOuvriers() {
		return nbOuvriers;
	}

	public static void setNbOuvriers(int nbOuvriers) {
		Ouvrier.nbOuvriers = nbOuvriers;
	}
	
	public String toString() {
		String res = "--- Ouvrier :\n";
		res += super.toString();
		res += "Num. Atelier : " + getNumeroAtelier() + "\n";
		return res;
	}

}
