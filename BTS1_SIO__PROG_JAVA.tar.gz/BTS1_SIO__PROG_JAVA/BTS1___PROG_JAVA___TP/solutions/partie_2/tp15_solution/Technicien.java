package tp15;

public class Technicien extends Employe {
	
	private static int nbTechniciens = 0;
	private String service;
	
	public Technicien(String nom, int salaire, String service) {
		super(nom, salaire);
		setService(service);
		nbTechniciens++;
	}

	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}

	public static int getNbTechniciens() {
		return nbTechniciens;
	}

	public static void setNbTechniciens(int nbTechniciens) {
		Technicien.nbTechniciens = nbTechniciens;
	}
	
	public String toString() {
		String res = "--- Technicien :\n";
		res += super.toString();
		res += "Service : " + getService() + "\n";
		return res;
	}
}
