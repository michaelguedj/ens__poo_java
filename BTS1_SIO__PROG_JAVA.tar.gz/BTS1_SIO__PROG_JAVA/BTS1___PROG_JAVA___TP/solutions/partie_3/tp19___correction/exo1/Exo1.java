package tpjdbc.exo1;

//STEP 1. Import required packages
import java.sql.*;

public class Exo1 {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/tp_jdbc";
	// Database credentials
	static final String USER = "root";
	static final String PASS = "";
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		try{
			//STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			//STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Connected database successfully...");
			//STEP 4: Execute a query
			System.out.println("Creating table in given database...");
			stmt = conn.createStatement();
			
			
			String sql;
			ResultSet resp;
			
			// 1- Quels sont les employ�s du service informatique�?
			sql = "SELECT * FROM `employe` WHERE code_service = \"INF\"";
			resp = stmt.executeQuery(sql);
			System.out.println("1- Quels sont les employ�s du service informatique�?");
			while(resp.next()) {
				System.out.println(resp.getString("prenom")+" "+resp.getString("nom"));
			}
			
			// 2- Quels sont les responsables�?
			sql = "SELECT * FROM `employe`, `service` WHERE employe.num_employe = service.responsable";
			resp = stmt.executeQuery(sql);
			System.out.println("2- Quels sont les responsables�?");
			while(resp.next()) {
				System.out.println(resp.getString("prenom")+" "+resp.getString("nom"));
			}
			
			// 3- Quels sont les employ�s gagnant plus de 1800 ��? 
			sql = "SELECT * FROM `employe` WHERE employe.salaire >= 1800";
			resp = stmt.executeQuery(sql);
			System.out.println("3- Quels sont les employ�s gagnant plus de 1800 ��?");
			while(resp.next()) {
				System.out.println(resp.getString("prenom")+" "+resp.getString("nom"));
			}

			// 4- Quel est le responsable de Jean-Pierre Dupont�?
			/* la requete : 
SELECT *
FROM `employe`
WHERE
	employe.num_employe =
	(SELECT service.responsable
	FROM  `service`
	WHERE 
		service.code_service = 
		(SELECT code_service FROM employe WHERE nom = "Dupond" and prenom = "Jean-Pierre"))
		
			 */


			sql = "SELECT * FROM `employe` WHERE employe.num_employe = (SELECT service.responsable FROM  `service` WHERE service.code_service =  (SELECT code_service FROM employe WHERE nom = \"Dupond\" and prenom = \"Jean-Pierre\"))";
			resp = stmt.executeQuery(sql);
			System.out.println("4- Quel est le responsable de Jean-Pierre Dupont�?");
			while(resp.next()) {
				System.out.println(resp.getString("prenom")+" "+resp.getString("nom"));
			}
			
		}catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}finally{
			//finally block used to close resources
			try{
				if(stmt!=null)
					conn.close();
			}catch(SQLException se){
			}// do nothing
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}//end finally try
		}//end try
		System.out.println("Goodbye!");
	}//end main
}//end JDBCExample
