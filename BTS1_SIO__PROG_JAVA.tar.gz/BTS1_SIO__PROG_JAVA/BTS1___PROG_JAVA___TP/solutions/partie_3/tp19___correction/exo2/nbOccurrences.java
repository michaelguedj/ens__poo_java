package tpjdbc.exo2;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;

public class nbOccurrences {
	public static void main(String args[]) {
		try {
			ArrayList<String> storeWordList = new ArrayList<String>();
			FileInputStream fstream = new FileInputStream(args[0]);
			String searchdWord = args[1];
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				storeWordList.add(strLine);

			}
			//Close the input stream
			in.close();

			//Writer output = null;
			//File file = new File(args[0].replaceAll(".txt", "_UnMotSurDeux.txt"));
			//output = new BufferedWriter(new FileWriter(file));

			int occurrences = 0;
			for (Iterator<String> iter = storeWordList.iterator(); iter.hasNext();) {
				String line = (String) iter.next(); 
				String[] words = line.split(" ");
				for(int i=0; i<words.length; i++)
					if(words[i].equals(searchdWord))
						occurrences++;
						
			}

			//output.close();
			System.out.println(occurrences);

		} catch(FileNotFoundException e) {
			System.err.println("Error: " + e.getMessage());
		} catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println("Usage : nbOccurences fileName");
		} catch (Exception e) {
			System.err.println("Error: " + e.getMessage());
		}
	}
}
