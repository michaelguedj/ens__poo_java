package tpjdbc.exo2;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.Writer;
//STEP 1. Import required packages
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
public class nbOccurrences2 {
	//JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost/tp_jdbc";
	//Database credentials
	static final String USER = "root";
	static final String PASS = "";
	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		Statement stmt2 = null;
		Statement stmt3 = null;
		try{
			//STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			//STEP 3: Open a connection
			System.out.println("Connecting to a selected database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Connected database successfully...");
			//STEP 4: Execute a query
			System.out.println("Inserting records into the table...");
			stmt = conn.createStatement();

			ArrayList<String> storeWordList = new ArrayList<String>();
			FileInputStream fstream = new FileInputStream(args[0]);
			// Get the object of DataInputStream
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String strLine;
			//Read File Line By Line
			while ((strLine = br.readLine()) != null) {
				storeWordList.add(strLine);

			}
			//Close the input stream
			in.close();

			// On execute la requete SQL pour vider la table histo_mots 
			stmt.executeUpdate("DELETE FROM histo_mots;");

			// On parcourt le fichier d'entree et on remplit la table tp_jdbc.histo_mots
			for (Iterator<String> iter = storeWordList.iterator(); iter.hasNext();) {
				String line = (String) iter.next(); 
				String[] words = line.split(" ");
				for(int i=0; i<words.length; i++) {
					String word = words[i];

					// on retire "." se trouvant eventuellement dans le mot
					word = word.replaceAll("\\.", "");
					// on retire "," se trouvant eventuellement dans le mot
					word = word.replaceAll(",", "");
					// on retire le double-quote se trouvant eventuellement dans le mot
					word = word.replaceAll("\"", "");
					
					System.out.println(word);
					
					String sql = "SELECT * FROM histo_mots WHERE mot =\""+ word +"\"";
					ResultSet resp = stmt.executeQuery(sql);
					
					String sqlUpdate="";
					
					int cpt=0;
					while(resp.next()) {
						int nbOccurrences = resp.getInt("nb_occurrences")+1;
						sqlUpdate = "UPDATE histo_mots SET nb_occurrences = "+ nbOccurrences +" Where mot =  \""+  word + "\"";
						cpt++;
					}

					// cpt = 1 ou 0, si 0 alors le mot ne se trouve pas dans la table
					if (cpt == 0) {    
						System.out.println("Pas dans la table"); 
						// to add a new record
						sqlUpdate = "INSERT INTO histo_mots " +
								"VALUES (\"" + word + "\"," + 1 +")";
					}
					stmt.executeUpdate(sqlUpdate);
				}
			}

			// On ecrit le fichier _histo.txt
			Writer output = null;
			File file = new File(args[0].replaceAll(".txt", "_histo.txt"));
			output = new BufferedWriter(new FileWriter(file));
			
			String sql = "SELECT mot, nb_occurrences FROM histo_mots ORDER BY mot";
			ResultSet resp = stmt.executeQuery(sql);
		
			while(resp.next()) {
				String mot = resp.getString("mot");
				int nbOccurrences = resp.getInt("nb_occurrences");
				output.write(mot+" "+nbOccurrences+"\n");
			}

			output.close();
			System.out.println("Your file has been written");

		} catch(FileNotFoundException e) {
			System.err.println("Error: " + e.getMessage());
		} catch(ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			System.out.println("Usage : cptTxt fileName");
		}catch(SQLException se){
			//Handle errors for JDBC
			se.printStackTrace();
		}catch(Exception e){
			//Handle errors for Class.forName
			e.printStackTrace();
		}finally{
			//finally block used to close resources
			try{
				if(stmt!=null)
					conn.close();
			}catch(SQLException se){
			}// do nothing
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}//end finally try
		}//end try
		System.out.println("Goodbye!");
	}//end main
}//end JDBCExample
